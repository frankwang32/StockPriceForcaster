<?php 
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','wangshi32');
define('DB_NAME','stockprice');

?>